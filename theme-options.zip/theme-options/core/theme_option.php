<?php

    /**
     * ReduxFramework Barebones Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "fruit";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Theme Options', 'redux-framework-demo' ),
        'page_title'           => __( 'Theme Options', 'redux-framework-demo' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '_options',
        // Page slug used to denote the panel
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => false,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'redux-framework-demo' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'redux-framework-demo' ),
    );
	
    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'redux-framework-demo' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'redux-framework-demo' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'redux-framework-demo' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'redux-framework-demo' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'redux-framework-demo' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

    // -> START Basic Field


//Journey for the redux framework here started
//Header
     Redux::setSection( $opt_name, array(
        'title' => __( 'Header', 'redux-framework-demo' ),
        'id'    => 'header',
        'desc'  => __( 'Basic fields as subsections.', 'redux-framework-demo' ),
        'icon'  => 'el el-caret-up'
    ) );
     
	 Redux::setSection( $opt_name, array(
        'title'      => __( 'Header logo', 'redux-framework-demo' ),
        'id'         => 'header-logo',
		'icon'  => 'el el-edit',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'header-logo',
                'type'     => 'media',
                'title'    => __( 'Upload Logo', 'redux-framework-demo' ),
                'desc'     => __( 'Add the logo here', 'redux-framework-demo' ),
				'hint' 	   => array ( 'content' => 'Add the logo here')
            ),
			array(
                'id'       => 'favicon',
                'type'     => 'media',
                'title'    => __( 'Upload Favicon', 'redux-framework-demo' ),
                'desc'     => __( 'Add the Favicon here', 'redux-framework-demo' ),
				'hint' 	   => array ( 'content' => 'Add Favicon here')
            ),
            array(
                'id'       => 'top-header',
                'type'     => 'text',
                'title'    => __( 'Add Opening Time', 'redux-framework-demo' ),
                'desc'     => __( 'Add Opening Time here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'AAdd Opening Time Here')
            ),
            array(
                'id'       => 'header-phon',
                'type'     => 'text',
                'title'    => __( 'Add Opening Time', 'redux-framework-demo' ),
                'desc'     => __( 'Add Opening Time here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'AAdd Opening Time Here')
            ),
            array(
                'id'       => 'header-email',
                'type'     => 'text',
                'title'    => __( 'Add Opening Time', 'redux-framework-demo' ),
                'desc'     => __( 'Add Opening Time here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'AAdd Opening Time Here')
            ),
        )
    ) );
//Custom Css
    Redux::setSection( $opt_name, array(
        'title' => __( 'Custom Style', 'redux-framework-demo' ),
        'id'    => 'custom_css',
        'desc'  => __( 'Basic fields as subsections.', 'redux-framework-demo' ),
        'icon'  => 'el el-cog'
    ) );
	
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Custom Css', 'redux-framework-demo' ),
        'id'         => 'css_custom',
		'icon'  => 'el el-edit',
        'subsection' => true,
        'fields'     => array(
            array(
                	'id'       => 'css_editor',
					'type'     => 'ace_editor',
					'title'    => __('CSS Code', 'redux-framework-demo'),
					'subtitle' => __('Paste your CSS code here.', 'redux-framework-demo'),
					'mode'     => 'css',
            ),
        )
    ) );
//Social section
    Redux::setSection( $opt_name, array(
        'title' => __( ' Social Media Top Header & Footer', 'redux-framework-demo' ),
        'id'    => 'social',
        'desc'  => __( 'Basic fields as subsections.', 'redux-framework-demo' ),
        'icon'  => 'el el-caret-down'
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header & Footer', 'redux-framework-demo' ),
        'id'         => 'top-social',
        'icon'  => 'el el-edit',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'facebook',
                'type'     => 'text',
                'title'    => __('Add facebook link', 'redux-framework-demo'),
                'title'    => __('Add facebook', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ),  
            array(
                'id'       => 'twitter',
                'type'     => 'text',
                'title'    => __('Add twitter', 'redux-framework-demo'),
                'title'    => __('Add twitter', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ), 
            array(
                'id'       => 'google-plus',
                'type'     => 'text',
                'title'    => __('Add google-plus', 'redux-framework-demo'),
                'title'    => __('Add google-plus', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ),
            array(
                'id'       => 'linkedin',
                'type'     => 'text',
                'title'    => __('Add linkedin', 'redux-framework-demo'),
                'title'    => __('Add linkedin', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ), 
            array(
                'id'       => 'youtube',
                'type'     => 'text',
                'title'    => __('Add youtube', 'redux-framework-demo'),
                'title'    => __('Add youtube', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ), 
            array(
                'id'       => 'pinterest',
                'type'     => 'text',
                'title'    => __('Add pinterest link', 'redux-framework-demo'),
                'title'    => __('Add pinterest', 'redux-framework-demo'),
                'desc'     => __( ' here', 'redux-framework-demo' ),
                'hint'     => array ( 'content' => 'Add the header social here'),
            ), 
        )
    ) );
//Footer section
    Redux::setSection( $opt_name, array(
        'title' => __( 'Footer', 'redux-framework-demo' ),
        'id'    => 'footer',
        'desc'  => __( 'Basic fields as subsections.', 'redux-framework-demo' ),
        'icon'  => 'el el-caret-down'
    ) );
//******************footer 1************************
Redux::setSection( $opt_name, array(
        'title'      => __( 'Copyright', 'redux-framework-demo' ),
        'id'         => 'copyright',
        'icon'  => 'el el-edit',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'footer_About',
                'type'     => 'editor',
                'title'     => 'Footer About',
                'hint'     => array ( 'content' => 'Add Copyright Text on Footer')
            ), 
            array(
                'id'       => 'footer_Contact',
                'type'     => 'editor',
                'title'     => 'Footer Contact',
                'hint'     => array ( 'content' => 'Add Copyright Text on Footer')
            ), 
            array(
                'id'       => 'footer_copyright',
                'type'     => 'text',
                'title'     => 'Footer Copyright',
                'hint'     => array ( 'content' => 'Add Copyright Text on Footer')
            ),                  
        )
    ) );
Redux::setSection( $opt_name, array(
        'title'      => __( 'Newslatter', 'redux-framework-demo' ),
        'id'         => 'newslatter',
        'icon'  => 'el el-edit',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'newslatter',
                'type'     => 'editor',
                'title'     => 'Footer Newslatter Text',
                'hint'     => array ( 'content' => 'Add newslatter text on Footer')
            ),            
        )
    ) );
    /*
     * <--- END SECTIONS
     */
